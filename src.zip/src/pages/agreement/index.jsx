import AgreementScreen from '@screens/agreement';
export default AgreementScreen;
