import RealTimeReviewScreen from '@screens/review/realtime';

export default RealTimeReviewScreen;
