import TermsIndexScreen from '@screens/terms/index';

export default TermsIndexScreen;
