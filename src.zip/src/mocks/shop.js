const shopHandlers = () => {
	return [];
};

export default shopHandlers();
