import ReviewIndexScreen from '@screens/review/list';

export default ReviewIndexScreen;
