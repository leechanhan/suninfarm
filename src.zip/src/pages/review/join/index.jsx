import ReviewCampaignJoinScreen from '@screens/review/join';

export default ReviewCampaignJoinScreen;
