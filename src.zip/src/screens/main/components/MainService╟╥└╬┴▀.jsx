import React from 'react';
import Service섹션영역 from './section/Service섹션영역';

const MainService할인중 = () => {
	return <Service섹션영역 serviceName="sale">지금할인중</Service섹션영역>;
};

export default MainService할인중;
