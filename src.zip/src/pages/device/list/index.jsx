import DeviceListScreen from '@screens/device/list';
export default DeviceListScreen;
