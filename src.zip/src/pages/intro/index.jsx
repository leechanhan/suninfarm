import IntroScreen from '@screens/intro';
export default IntroScreen;
