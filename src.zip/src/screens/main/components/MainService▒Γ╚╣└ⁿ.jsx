import React from 'react';
import Service섹션영역 from './section/Service섹션영역';

const MainService기획전 = () => {
	return (
		<Service섹션영역
			serviceName="pick"
			serviceNameKor="아이보리 기획전"
		>
			기획전
		</Service섹션영역>
	);
};

export default MainService기획전;
