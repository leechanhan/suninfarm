import AddFarmScreen from '@screens/farm/add';
export default AddFarmScreen;
