import React from 'react';

const Service섹션헤더 = ({ title }) => {
	return (
		<h2 className="service_section_title">
			<p>{title}</p>
		</h2>
	);
};

export default Service섹션헤더;
