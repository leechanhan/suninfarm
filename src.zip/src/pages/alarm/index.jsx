import AlarmScreen from '@screens/alarm';
export default AlarmScreen;
