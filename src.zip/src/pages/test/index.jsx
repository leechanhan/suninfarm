import TestIndexScreen from '@screens/test/index';

export default TestIndexScreen;
