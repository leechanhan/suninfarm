import ReviewProductScreen from '@screens/review/product';

export default ReviewProductScreen;
