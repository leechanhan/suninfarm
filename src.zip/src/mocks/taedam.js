const TaedamMainPreviewMock = {};

const taedamHandlers = () => {
	return [];
};

export default taedamHandlers();
