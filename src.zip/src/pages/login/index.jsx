import LoginScreen from '@screens/login/index';

export default LoginScreen;
