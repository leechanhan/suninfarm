import React from 'react';

const ReviewDetailScreen = () => {
	return <div></div>;
};

export default ReviewDetailScreen;
