import ReviewBrandScreen from '@screens/review/brand';

export default ReviewBrandScreen;
