import JoinScreen from '@screens/join';
export default JoinScreen;
