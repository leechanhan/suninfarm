const customerHandlers = () => {
	return [];
};

export default customerHandlers();
