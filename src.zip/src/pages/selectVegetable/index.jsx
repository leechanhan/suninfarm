import SelectVegetableScreen from '@screens/selectVegetable';
export default SelectVegetableScreen;
