import GatewaySettingScreen from '@screens/gatewaySetting';
export default GatewaySettingScreen;
