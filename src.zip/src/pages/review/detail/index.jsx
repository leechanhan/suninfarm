import ReviewDetailScreen from '@screens/review/detail';

export default ReviewDetailScreen;
