import FarmDetailScreen from '@screens/farm/detail';
export default FarmDetailScreen;
