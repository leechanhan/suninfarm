import ExampleScreen from '../../screens/example';

export default ExampleScreen;
