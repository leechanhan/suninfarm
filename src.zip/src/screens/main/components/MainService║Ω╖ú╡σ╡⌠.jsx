import React from 'react';
import Service섹션영역 from './section/Service섹션영역';

const MainService브랜드딜 = () => {
	return <Service섹션영역 serviceName="deal">브랜드딜</Service섹션영역>;
};

export default MainService브랜드딜;
