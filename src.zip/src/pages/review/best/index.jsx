import ReviewBestScreen from '@screens/review/best';

export default ReviewBestScreen;
