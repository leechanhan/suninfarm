import FarmListScreen from '@screens/farm/list';
export default FarmListScreen;
